document.getElementById("add").addEventListener("click",Add);
document.getElementById("sub").addEventListener("click",Sub);
document.getElementById("mul").addEventListener("click",Mul);
document.getElementById("div").addEventListener("click",Div);

  function Add()
{
     var a = parseInt(document.getElementById("n1").value);
     var b = parseInt(document.getElementById("n2").value);
   document.getElementById("p1").innerHTML=" Addition of " +a+ " and " + b +" is " + (a+b);    
}


  function Sub()
{
     var a = parseInt(document.getElementById("n1").value);
     var b = parseInt(document.getElementById("n2").value);
    document.getElementById("p1").innerHTML=" Substraction of " +a +" and " + b +" is " + (a-b);    
}


  function Mul()
{
     var a = parseInt(document.getElementById("n1").value);
     var b = parseInt(document.getElementById("n2").value);
   document.getElementById("p1").innerHTML=" multiplication  of " +a +" and " + b +" is " + (a*b);    
}


  function Div()
{
     var a = parseInt(document.getElementById("n1").value);
     var b = parseInt(document.getElementById("n2").value);
    document.getElementById("p1").innerHTML=" Division of " +a +" and " + b +" is  " + (a/b);    
}
